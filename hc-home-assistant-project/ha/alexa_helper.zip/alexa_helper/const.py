"""Constants for Alexa Helper."""

DOMAIN = "alexa_helper"

CONF_PRIMARY = "primary_agent"
CONF_BACKUP_1 = "backup_agent_1"
CONF_BACKUP_2 = "backup_agent_2"
CONF_TIMEOUT = "timeout"
CONF_MESSAGE = "failure_message"
CONF_TAVILY_KEY = "tavily_api_key"

DEFAULT_NAME = "Alexa (with backup)"
DEFAULT_TIMEOUT = 30
DEFAULT_MESSAGE = "Sorry, I'm having trouble thinking right now. Please try again in a minute."

EVENT_ANSWERED = "alexa_helper_answered"
SERVICE_WEB_SEARCH = "web_search"
