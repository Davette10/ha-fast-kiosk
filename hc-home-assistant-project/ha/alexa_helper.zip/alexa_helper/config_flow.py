"""Setup and options for Alexa Helper."""

from __future__ import annotations

from typing import Any

import voluptuous as vol

from homeassistant.config_entries import ConfigEntry, ConfigFlow, ConfigFlowResult, OptionsFlow
from homeassistant.const import CONF_NAME
from homeassistant.core import callback
from homeassistant.helpers import selector

from .const import (
    CONF_BACKUP_1,
    CONF_BACKUP_2,
    CONF_MESSAGE,
    CONF_PRIMARY,
    CONF_TAVILY_KEY,
    CONF_TIMEOUT,
    DEFAULT_MESSAGE,
    DEFAULT_NAME,
    DEFAULT_TIMEOUT,
    DOMAIN,
)

_AGENT = selector.EntitySelector(selector.EntitySelectorConfig(domain="conversation"))


def _schema(current: dict[str, Any], with_name: bool) -> vol.Schema:
    fields: dict[Any, Any] = {}
    if with_name:
        fields[vol.Required(CONF_NAME, default=current.get(CONF_NAME, DEFAULT_NAME))] = selector.TextSelector()
    fields[vol.Required(CONF_PRIMARY, description={"suggested_value": current.get(CONF_PRIMARY)})] = _AGENT
    fields[vol.Optional(CONF_BACKUP_1, description={"suggested_value": current.get(CONF_BACKUP_1)})] = _AGENT
    fields[vol.Optional(CONF_BACKUP_2, description={"suggested_value": current.get(CONF_BACKUP_2)})] = _AGENT
    fields[vol.Required(CONF_TIMEOUT, default=current.get(CONF_TIMEOUT, DEFAULT_TIMEOUT))] = selector.NumberSelector(
        selector.NumberSelectorConfig(min=5, max=120, step=1, unit_of_measurement="s", mode=selector.NumberSelectorMode.BOX)
    )
    fields[vol.Required(CONF_MESSAGE, default=current.get(CONF_MESSAGE, DEFAULT_MESSAGE))] = selector.TextSelector()
    fields[vol.Optional(CONF_TAVILY_KEY, description={"suggested_value": current.get(CONF_TAVILY_KEY)})] = selector.TextSelector(
        selector.TextSelectorConfig(type=selector.TextSelectorType.PASSWORD)
    )
    return vol.Schema(fields)


class AlexaHelperConfigFlow(ConfigFlow, domain=DOMAIN):
    VERSION = 1

    async def async_step_user(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        if self._async_current_entries():
            return self.async_abort(reason="single_instance_allowed")
        if user_input is not None:
            name = user_input.pop(CONF_NAME, DEFAULT_NAME)
            return self.async_create_entry(title=name, data=user_input)
        return self.async_show_form(step_id="user", data_schema=_schema({}, True))

    @staticmethod
    @callback
    def async_get_options_flow(config_entry: ConfigEntry) -> OptionsFlow:
        return AlexaHelperOptionsFlow()


class AlexaHelperOptionsFlow(OptionsFlow):
    async def async_step_init(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        current = dict(self.config_entry.options or self.config_entry.data)
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)
        return self.async_show_form(step_id="init", data_schema=_schema(current, False))
