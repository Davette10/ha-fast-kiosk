"""Fresh web results for the voice assistant.

Tavily (free plan: 1,000 searches a month, no card) when a key is set,
otherwise free keyless sources: Google News RSS, Wikipedia and DuckDuckGo
instant answers. Results are trimmed so they fit easily in the AI's context.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from email.utils import parsedate_to_datetime
import html
import logging
import re
from typing import Any
from urllib.parse import quote, urlencode
import xml.etree.ElementTree as ET

import aiohttp

from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.util import dt as dt_util

_LOGGER = logging.getLogger(__name__)

_UA = "HomeAssistant-AlexaHelper/1.0 (family voice assistant; home use)"
_TIMEOUT = aiohttp.ClientTimeout(total=8)
_TAG = re.compile(r"<[^>]+>")


def _clean(text: str | None, limit: int = 500) -> str:
    text = html.unescape(_TAG.sub(" ", text or ""))
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= limit else text[: limit - 1].rsplit(" ", 1)[0] + "…"


def _age(when: datetime | None) -> str | None:
    if when is None:
        return None
    days = (dt_util.now() - when).total_seconds() / 86400
    if days < 1:
        return "today"
    if days < 2:
        return "yesterday"
    return f"{int(days)} days ago"


async def async_web_search(
    hass: HomeAssistant,
    query: str,
    max_results: int = 5,
    topic: str = "general",
    tavily_key: str | None = None,
) -> dict[str, Any]:
    session = async_get_clientsession(hass)
    today = dt_util.now().strftime("%A, %B %-d, %Y")

    if tavily_key:
        try:
            result = await _tavily(session, query, max_results, topic, tavily_key)
            result["today"] = today
            return result
        except Exception as err:  # noqa: BLE001
            _LOGGER.warning("Tavily search failed, using the free sources: %s", err)

    news, wiki, ddg = await asyncio.gather(
        _google_news(session, query, max_results),
        _wikipedia(session, query),
        _duckduckgo(session, query),
        return_exceptions=True,
    )
    out: dict[str, Any] = {"source": "free (Google News, Wikipedia, DuckDuckGo)", "today": today}
    if isinstance(ddg, dict) and ddg:
        out["instant_answer"] = ddg
    if isinstance(news, list) and news:
        out["news"] = news
    if isinstance(wiki, list) and wiki:
        out["reference"] = wiki
    for name, value in (("news", news), ("wikipedia", wiki), ("duckduckgo", ddg)):
        if isinstance(value, Exception):
            _LOGGER.debug("%s lookup failed: %s", name, value)
    if not any(k in out for k in ("instant_answer", "news", "reference")):
        out["note"] = "Nothing found online for that."
    return out


async def _tavily(session, query, max_results, topic, key) -> dict[str, Any]:
    body = {
        "query": query,
        "topic": topic,
        "search_depth": "basic",
        "max_results": max_results,
        "include_answer": "basic",
        "include_published_date": True,
    }
    async with session.post(
        "https://api.tavily.com/search",
        json=body,
        headers={"Authorization": f"Bearer {key}"},
        timeout=_TIMEOUT,
    ) as resp:
        if resp.status != 200:
            raise RuntimeError(f"HTTP {resp.status}")
        data = await resp.json(content_type=None)
    results = []
    for item in data.get("results") or []:
        results.append(
            {
                "title": _clean(item.get("title"), 160),
                "site": re.sub(r"^https?://(www\.)?([^/]+).*$", r"\2", item.get("url") or ""),
                "published": item.get("published_date"),
                "text": _clean(item.get("content"), 600),
            }
        )
    out: dict[str, Any] = {"source": "Tavily web search", "results": results}
    if data.get("answer"):
        out["answer"] = _clean(data["answer"], 600)
    return out


async def _google_news(session, query, max_results) -> list[dict[str, Any]]:
    url = "https://news.google.com/rss/search?" + urlencode(
        {"q": query, "hl": "en-US", "gl": "US", "ceid": "US:en"}
    )
    async with session.get(url, headers={"User-Agent": _UA}, timeout=_TIMEOUT) as resp:
        if resp.status != 200:
            raise RuntimeError(f"HTTP {resp.status}")
        text = await resp.text()
    root = ET.fromstring(text)
    items = []
    for item in root.iter("item"):
        title = _clean(item.findtext("title"), 200)
        source = _clean(item.findtext("source"), 60)
        if source and title.endswith(" - " + source):
            title = title[: -len(source) - 3]
        when = None
        try:
            when = parsedate_to_datetime(item.findtext("pubDate") or "")
        except (TypeError, ValueError):
            pass
        items.append(
            {
                "headline": title,
                "source": source,
                "published": when.date().isoformat() if when else None,
                "age": _age(when),
                "_ts": when.timestamp() if when else 0,
            }
        )
    # Google already ranks by relevance; keep that order but drop stale items
    # when there are enough fresh ones.
    fresh = [i for i in items[: max_results * 3] if i["_ts"] and (dt_util.now().timestamp() - i["_ts"]) < 45 * 86400]
    chosen = (fresh if len(fresh) >= 2 else items)[:max_results]
    for i in chosen:
        i.pop("_ts", None)
    return chosen


async def _wikipedia(session, query) -> list[dict[str, Any]]:
    headers = {"User-Agent": _UA}
    url = "https://en.wikipedia.org/w/rest.php/v1/search/page?" + urlencode({"q": query, "limit": 3})
    async with session.get(url, headers=headers, timeout=_TIMEOUT) as resp:
        if resp.status != 200:
            raise RuntimeError(f"HTTP {resp.status}")
        data = await resp.json(content_type=None)
    pages = (data.get("pages") or [])[:2]

    async def summary(page):
        key = page.get("key") or page.get("title", "").replace(" ", "_")
        async with session.get(
            "https://en.wikipedia.org/api/rest_v1/page/summary/" + quote(key, safe=""),
            headers=headers,
            timeout=_TIMEOUT,
        ) as resp:
            if resp.status != 200:
                return None
            s = await resp.json(content_type=None)
        return {
            "title": s.get("title") or page.get("title"),
            "description": _clean(s.get("description"), 120),
            "summary": _clean(s.get("extract"), 700),
            "page_updated": (s.get("timestamp") or "")[:10] or None,
        }

    found = await asyncio.gather(*(summary(p) for p in pages), return_exceptions=True)
    return [f for f in found if isinstance(f, dict) and f.get("summary")]


async def _duckduckgo(session, query) -> dict[str, Any]:
    url = "https://api.duckduckgo.com/?" + urlencode(
        {"q": query, "format": "json", "no_html": 1, "skip_disambig": 1, "no_redirect": 1}
    )
    async with session.get(url, headers={"User-Agent": _UA}, timeout=_TIMEOUT) as resp:
        if resp.status != 200:
            raise RuntimeError(f"HTTP {resp.status}")
        data = await resp.json(content_type=None)
    out = {}
    if data.get("Answer"):
        out["answer"] = _clean(str(data["Answer"]), 300)
    if data.get("AbstractText"):
        out["abstract"] = _clean(data["AbstractText"], 500)
        out["from"] = data.get("AbstractSource")
    return out
