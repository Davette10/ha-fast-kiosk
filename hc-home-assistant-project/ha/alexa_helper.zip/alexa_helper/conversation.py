"""Conversation agent that falls back to backup agents when the main one fails."""

from __future__ import annotations

import asyncio
import inspect
import logging
import re
import time
from typing import Any

from homeassistant.components import conversation
from homeassistant.components.conversation import ConversationInput, ConversationResult
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import MATCH_ALL
from homeassistant.core import HomeAssistant
from homeassistant.helpers import intent
from homeassistant.util import dt as dt_util

from .const import (
    CONF_BACKUP_1,
    CONF_BACKUP_2,
    CONF_MESSAGE,
    CONF_PRIMARY,
    CONF_TIMEOUT,
    DEFAULT_MESSAGE,
    DEFAULT_TIMEOUT,
    DOMAIN,
    EVENT_ANSWERED,
)

_LOGGER = logging.getLogger(__name__)

# Text that only shows up when an AI integration reports a failure as the reply.
_FAILURE_TEXT = re.compile(
    r"problem talking to|error talking to|unable to generate|RESOURCE_EXHAUSTED|"
    r"experiencing high demand|model is overloaded|exceeded your current quota|"
    r"\b(?:429|500|502|503|504)\b\s*(?:UNAVAILABLE|RESOURCE_EXHAUSTED|INTERNAL|Too Many|Service Unavailable)",
    re.IGNORECASE,
)

try:
    _CONVERSE_PARAMS = set(inspect.signature(conversation.async_converse).parameters)
except (TypeError, ValueError):  # pragma: no cover
    _CONVERSE_PARAMS = set()


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities) -> None:
    async_add_entities([AlexaBackupAgent(entry)])


def _speech(result: ConversationResult | None) -> str:
    try:
        return (result.response.speech or {}).get("plain", {}).get("speech", "") or ""
    except AttributeError:
        return ""


def _failure_reason(result: ConversationResult | None) -> str | None:
    """Return why a result counts as a failure, or None if it is a real answer."""
    if result is None or getattr(result, "response", None) is None:
        return "no response"
    response = result.response
    speech = _speech(result)
    if response.response_type == intent.IntentResponseType.ERROR:
        code = getattr(response.error_code, "value", response.error_code)
        # Errors such as "no device called X" are real answers; only treat
        # unknown / failed-to-handle (what AI integrations use) as a failure.
        if code in (None, "unknown", "failed_to_handle") or _FAILURE_TEXT.search(speech):
            return f"{code}: {speech}"[:300]
        return None
    if _FAILURE_TEXT.search(speech) and len(speech) < 500:
        return f"error text in reply: {speech}"[:300]
    return None


class AlexaBackupAgent(conversation.ConversationEntity):
    """Tries the main agent, then each backup agent, then a friendly message."""

    _attr_should_poll = False
    _attr_supports_streaming = False

    def __init__(self, entry: ConfigEntry) -> None:
        self.entry = entry
        self._attr_name = entry.title
        self._attr_unique_id = entry.entry_id
        self._attr_icon = "mdi:account-voice"
        self._attr_supported_features = conversation.ConversationEntityFeature.CONTROL
        self._info: dict[str, Any] = {}

    @property
    def supported_languages(self):
        return MATCH_ALL

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        return {"agents": self._agents(), **self._info}

    def _cfg(self) -> dict:
        return dict(self.entry.options) if self.entry.options else dict(self.entry.data)

    def _agents(self) -> list[str]:
        cfg = self._cfg()
        agents: list[str] = []
        for key in (CONF_PRIMARY, CONF_BACKUP_1, CONF_BACKUP_2):
            agent = cfg.get(key)
            if agent and agent != self.entity_id and agent not in agents:
                agents.append(agent)
        return agents

    async def _converse(self, agent_id: str, user_input: ConversationInput) -> ConversationResult:
        kwargs: dict[str, Any] = {
            "hass": self.hass,
            "text": user_input.text,
            "conversation_id": user_input.conversation_id,
            "context": user_input.context,
            "language": user_input.language,
            "agent_id": agent_id,
        }
        for name in ("device_id", "satellite_id", "extra_system_prompt"):
            value = getattr(user_input, name, None)
            if value is not None and name in _CONVERSE_PARAMS:
                kwargs[name] = value
        return await conversation.async_converse(**kwargs)

    async def async_process(self, user_input: ConversationInput) -> ConversationResult:
        return await self._run(user_input)

    async def _async_handle_message(self, user_input: ConversationInput, chat_log) -> ConversationResult:
        # Newer Home Assistant versions call this instead of async_process.
        return await self._run(user_input)

    async def _run(self, user_input: ConversationInput) -> ConversationResult:
        cfg = self._cfg()
        timeout = float(cfg.get(CONF_TIMEOUT, DEFAULT_TIMEOUT))
        errors: list[dict[str, str]] = []
        started = time.monotonic()

        for index, agent_id in enumerate(self._agents()):
            state = self.hass.states.get(agent_id)
            if state is None or state.state == "unavailable":
                errors.append({"agent": agent_id, "error": "agent unavailable"})
                continue
            t0 = time.monotonic()
            result: ConversationResult | None = None
            try:
                result = await asyncio.wait_for(self._converse(agent_id, user_input), timeout)
                reason = _failure_reason(result)
            except asyncio.TimeoutError:
                reason = f"no answer after {timeout:.0f} s"
            except Exception as err:  # noqa: BLE001 - any failure moves on to the next agent
                reason = f"{type(err).__name__}: {err}"[:300]
            if reason is None:
                self._remember(agent_id, index, errors, time.monotonic() - t0, user_input)
                return result
            errors.append({"agent": agent_id, "error": reason})
            _LOGGER.warning("Agent %s failed (%s); trying the next one", agent_id, reason)

        # Every agent failed: one calm sentence instead of an error dump.
        message = cfg.get(CONF_MESSAGE) or DEFAULT_MESSAGE
        response = intent.IntentResponse(language=user_input.language)
        response.async_set_speech(message)
        self._remember(None, -1, errors, time.monotonic() - started, user_input)
        return ConversationResult(response=response, conversation_id=user_input.conversation_id)

    def _remember(self, agent_id, index, errors, seconds, user_input) -> None:
        self._info = {
            "last_agent": agent_id,
            "last_used_backup": index > 0 or agent_id is None,
            "last_errors": errors,
            "last_seconds": round(seconds, 2),
            "last_time": dt_util.now().isoformat(),
        }
        self.hass.bus.async_fire(
            EVENT_ANSWERED,
            {
                "agent": agent_id,
                "used_backup": index > 0 or agent_id is None,
                "all_failed": agent_id is None,
                "errors": errors,
                "text": user_input.text,
                "device_id": getattr(user_input, "device_id", None),
            },
        )
        if self.hass is not None and self.entity_id:
            self.async_write_ha_state()
