"""Album art from Music Assistant, served over Home Assistant's own (HTTPS) address.

Music Assistant hands out artwork as plain-http links on the local network
(http://<ma-host>:8095/imageproxy/<hash>), which browsers refuse to load inside
an https dashboard. This view fetches that one image server-side and returns it.
Only Music Assistant's imageproxy is reachable through it: the path must be a
hex hash and the host is fixed, so it cannot be used to fetch anything else.
"""

from __future__ import annotations

import re

from aiohttp import ClientTimeout, web

from homeassistant.components.http import HomeAssistantView
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession

MA_BASE = "http://192.168.6.172:8095"
_KEY = re.compile(r"[0-9a-f]{16,128}")


class AlbumArtView(HomeAssistantView):
    url = "/api/alexa_helper/art/{key}"
    name = "api:alexa_helper:art"
    requires_auth = False  # <img> tags cannot send a token; the view only serves MA artwork

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass

    async def get(self, request: web.Request, key: str) -> web.Response:
        if not _KEY.fullmatch(key):
            return web.Response(status=404)
        size = request.query.get("size", "300")
        if not size.isdigit() or int(size) > 1200:
            size = "300"
        session = async_get_clientsession(self.hass)
        try:
            async with session.get(
                f"{MA_BASE}/imageproxy/{key}", params={"size": size}, timeout=ClientTimeout(total=10)
            ) as resp:
                if resp.status != 200:
                    return web.Response(status=404)
                body = await resp.read()
                ctype = (resp.headers.get("Content-Type") or "image/jpeg").split(";")[0]
        except Exception:  # noqa: BLE001
            return web.Response(status=502)
        if not ctype.startswith("image/"):
            return web.Response(status=404)
        return web.Response(body=body, content_type=ctype, headers={"Cache-Control": "public, max-age=604800"})
