"""Alexa Helper.

1. A conversation agent, "Alexa (with backup)", that hands each request to the
   main agent and, if that agent errors out (Google busy, quota, timeout), to
   up to two backup agents. If every agent fails it says one friendly sentence
   instead of reading an error out loud.
2. An action, alexa_helper.web_search, that returns fresh results from the web
   for the voice assistant. With a Tavily key (free plan, no card) it uses
   Tavily; without one it uses free sources (Google News RSS, Wikipedia,
   DuckDuckGo instant answers).
3. Two to-do lists, "Alexa Memory" and "Alexa Phrases": what the household has
   told Alexa to remember and how this family phrases things. Their open items
   are published in a `notes` attribute that the prompt template reads.
4. /api/alexa_helper/art/<hash>: Music Assistant album art over HA's https
   address, so the music players can show it.
"""

from __future__ import annotations

import logging

import voluptuous as vol

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import Platform
from homeassistant.core import HomeAssistant, ServiceCall, ServiceResponse, SupportsResponse
from homeassistant.helpers import config_validation as cv

from .const import CONF_TAVILY_KEY, DOMAIN, SERVICE_WEB_SEARCH
from .images import AlbumArtView
from .search import async_web_search

_LOGGER = logging.getLogger(__name__)

PLATFORMS = [Platform.CONVERSATION, Platform.TODO]

SEARCH_SCHEMA = vol.Schema(
    {
        vol.Required("query"): cv.string,
        vol.Optional("max_results", default=5): vol.All(vol.Coerce(int), vol.Range(min=1, max=10)),
        vol.Optional("topic", default="general"): vol.In(["general", "news"]),
    }
)


def entry_config(entry: ConfigEntry) -> dict:
    """Options win over the original setup data once the user has edited them."""
    return dict(entry.options) if entry.options else dict(entry.data)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = entry

    async def handle_search(call: ServiceCall) -> ServiceResponse:
        key = None
        for e in hass.config_entries.async_entries(DOMAIN):
            key = (entry_config(e).get(CONF_TAVILY_KEY) or "").strip() or None
            if key:
                break
        return await async_web_search(
            hass, call.data["query"], call.data["max_results"], call.data["topic"], key
        )

    if not hass.data[DOMAIN].get("_art_view"):
        hass.http.register_view(AlbumArtView(hass))
        hass.data[DOMAIN]["_art_view"] = True

    if not hass.services.has_service(DOMAIN, SERVICE_WEB_SEARCH):
        hass.services.async_register(
            DOMAIN,
            SERVICE_WEB_SEARCH,
            handle_search,
            schema=SEARCH_SCHEMA,
            supports_response=SupportsResponse.ONLY,
        )

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    entry.async_on_unload(entry.add_update_listener(_async_reload))
    return True


async def _async_reload(hass: HomeAssistant, entry: ConfigEntry) -> None:
    await hass.config_entries.async_reload(entry.entry_id)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    hass.data.get(DOMAIN, {}).pop(entry.entry_id, None)
    if not any(k != "_art_view" for k in hass.data.get(DOMAIN, {})):
        hass.services.async_remove(DOMAIN, SERVICE_WEB_SEARCH)
    return ok
