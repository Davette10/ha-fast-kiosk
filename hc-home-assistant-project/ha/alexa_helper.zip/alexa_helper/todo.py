"""Alexa's long-term memory and household phrase book, as two to-do lists.

Each open item is one note. Open items are also published in the entity's
`notes` attribute so the assistant's prompt template can include them:

    {{ state_attr('todo.alexa_memory', 'notes') }}

Anyone can read, edit, reorder or delete notes from the Home Assistant To-do
page. Checking an item off keeps it but hides it from Alexa. Notes live in
.storage/alexa_helper.<list> and survive restarts.
"""

from __future__ import annotations

from typing import Any
from uuid import uuid4

from homeassistant.components.todo import (
    TodoItem,
    TodoItemStatus,
    TodoListEntity,
    TodoListEntityFeature,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store
from homeassistant.util import dt as dt_util

LISTS = (
    ("memory", "Alexa Memory", "mdi:brain"),
    ("phrases", "Alexa Phrases", "mdi:comment-quote-outline"),
)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities) -> None:
    async_add_entities([NotesList(hass, entry, key, name, icon) for key, name, icon in LISTS])


class NotesList(TodoListEntity):
    _attr_should_poll = False
    _attr_has_entity_name = False
    _unrecorded_attributes = frozenset({"notes"})
    _attr_supported_features = (
        TodoListEntityFeature.CREATE_TODO_ITEM
        | TodoListEntityFeature.UPDATE_TODO_ITEM
        | TodoListEntityFeature.DELETE_TODO_ITEM
        | TodoListEntityFeature.MOVE_TODO_ITEM
        | TodoListEntityFeature.SET_DESCRIPTION_ON_ITEM
    )

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry, key: str, name: str, icon: str) -> None:
        self._store: Store = Store(hass, 1, f"alexa_helper.{key}")
        self._attr_unique_id = f"{entry.entry_id}_{key}"
        self._attr_name = name
        self._attr_icon = icon
        self._items: list[dict[str, Any]] = []

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        data = await self._store.async_load() or {}
        self._items = list(data.get("items", []))
        self.async_write_ha_state()

    # ----- what Home Assistant and the prompt see -----
    @property
    def todo_items(self) -> list[TodoItem]:
        return [
            TodoItem(
                summary=i["summary"],
                uid=i["uid"],
                status=TodoItemStatus(i.get("status", TodoItemStatus.NEEDS_ACTION)),
                description=i.get("description"),
            )
            for i in self._items
        ]

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        return {
            "notes": [
                i["summary"] for i in self._items if i.get("status", "needs_action") == TodoItemStatus.NEEDS_ACTION
            ]
        }

    # ----- changes -----
    async def _save(self) -> None:
        await self._store.async_save({"items": self._items})
        self.async_write_ha_state()

    async def async_create_todo_item(self, item: TodoItem) -> None:
        summary = (item.summary or "").strip()
        if not summary:
            return
        # Never store the same note twice (case and spacing ignored).
        norm = " ".join(summary.lower().split())
        for existing in self._items:
            if " ".join(existing["summary"].lower().split()) == norm:
                existing["status"] = TodoItemStatus.NEEDS_ACTION
                await self._save()
                return
        self._items.append(
            {
                "uid": uuid4().hex,
                "summary": summary,
                "status": item.status or TodoItemStatus.NEEDS_ACTION,
                "description": item.description or f"Saved {dt_util.now().strftime('%b %-d, %Y')}",
            }
        )
        await self._save()

    async def async_update_todo_item(self, item: TodoItem) -> None:
        for existing in self._items:
            if existing["uid"] == item.uid:
                if item.summary is not None:
                    existing["summary"] = item.summary.strip()
                if item.status is not None:
                    existing["status"] = item.status
                if item.description is not None:
                    existing["description"] = item.description
                break
        await self._save()

    async def async_delete_todo_items(self, uids: list[str]) -> None:
        drop = set(uids)
        self._items = [i for i in self._items if i["uid"] not in drop]
        await self._save()

    async def async_move_todo_item(self, uid: str, previous_uid: str | None = None) -> None:
        moving = next((i for i in self._items if i["uid"] == uid), None)
        if moving is None:
            return
        self._items.remove(moving)
        index = 0
        if previous_uid:
            for n, i in enumerate(self._items):
                if i["uid"] == previous_uid:
                    index = n + 1
                    break
        self._items.insert(index, moving)
        await self._save()
